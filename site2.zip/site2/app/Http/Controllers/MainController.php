<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MainController extends Controller {

    public function forLend() {
        return view('Lend');
    }

    public function forCP() {
        return view('ConteinerPage');
    }

    public function forIP() {
        return view('InfoPage');
    }

    public function review() {
        return view('yourReview');
    }

    public function check(Request $request) {
        $valid = $request->validate([
            'username' => 'required|min:5|max:50',
            'email' => 'required|min:5|max:50',
            'message' => 'required|min:15|max:500'
        ]);
        dd($request);
    }

}
