@extends('InfoPage')

@section('content')

@endsection
