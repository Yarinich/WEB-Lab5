<?php $__env->startSection('content'); ?>
    <div class="sixSectionText"> Hello </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('InfoPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Vetalik\laravel\site2\resources\views/InfoWithReview.blade.php ENDPATH**/ ?>