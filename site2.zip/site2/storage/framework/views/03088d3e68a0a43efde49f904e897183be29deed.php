<?php $__env->startSection('title'); ?> Star Wars <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <head> <link rel="stylesheet" href="styleCP.css"> </head>
    <div class="imgFirst">
        <img src="img/Star-Wars-big.png" class="img1">
    </div>

    <div class="choise">
        <div class="container button">
            <div class="row">
                <div class="col-sm">
                    <div class="Buttons">
                        <a href="/InfoPage" class="gradient-button">Фільми/серіали Star Wars </a>
                    </div>

                </div>

                <div class="col-sm">
                    <div class="Buttons">
                        <a href="/InfoPage" class="gradient-button">Мультфільми Star Wars </a>
                    </div>
                </div>

                <div class="col-sm">
                    <div class="Buttons">
                        <a href="/InfoPage" class="gradient-button">Новини по лору Star Wars </a>
                    </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Vetalik\laravel\site2\resources\views/ConteinerPage.blade.php ENDPATH**/ ?>